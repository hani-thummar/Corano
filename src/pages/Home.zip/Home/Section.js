import React from 'react';
import { Container, Grid, Box, IconButton, Typography, Button } from '@mui/material';
import Slider from 'react-slick';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import ArrowBackIosIcon from '@mui/icons-material/ArrowBackIos';
import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos';
import slide1 from '../../assets/img/HomePage/Slide 1.webp'
import slide2 from '../../assets/img/HomePage/Slide 2.webp'
import slide3 from '../../assets/img/HomePage/Slide 3.webp'

const NextArrow = (props) => {
  const { onClick } = props;
  return (
    <IconButton
      onClick={onClick}
      sx={{
        display: 'none',
        // borderRadius: '50%',
        position: 'absolute',
        top: '50%',
        right: '10px',
        transform: 'translateY(-50%)',
        width: '40px',
        height: '40px',
        zIndex: 1,
      }}
      className="next-arrow"
    >
      <ArrowForwardIosIcon />
    </IconButton>
  );
};

const PrevArrow = (props) => {
  const { onClick } = props;
  return (
    <IconButton
      onClick={onClick}
      sx={{
        display: 'none',
        // borderRadius: '50%',
        position: 'absolute',
        top: '50%',
        left: '10px',
        transform: 'translateY(-50%)',
        width: '40px',
        height: '40px',
        zIndex: 1,
      }}
      className="prev-arrow"
    >
      <ArrowBackIosIcon />
    </IconButton>
  );
};

function ServicesLogo() {
  const settings = {
    dots: false,
    infinite: true,
    speed: 900,
    slidesToShow: 1,
    slidesToScroll: 1,
    nextArrow: <NextArrow />,
    prevArrow: <PrevArrow />,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 1,
          infinite: true,
          dots: false
        }
      },
      {
        breakpoint: 768,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1
        }
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1
        }
      }
    ]
  };

  return (
    <Box>
      
        <Grid item xs={12}>
          <Box
            sx={{
              position: 'relative',
              '&:hover .next-arrow, &:hover .prev-arrow': {
                display: 'block'
              },
            }}
          >
            <Slider {...settings} sx={{border:"none !important"}}>
              <Box sx={{ position: 'relative',border:"none"}}>
                <img src={slide1} alt="logo1" style={{ width: '100%', height: '100%' }} />
                <Box sx={{ position: "absolute", top: "30%", left: "10%" }}>
                  <Typography variant='h2'>Grace Designer</Typography>
                  <Typography variant='h2'>Jewelry</Typography>
                  <Typography fontSize={"17px"} color={"#222222"} marginTop={"10px"}>Rings, Occasion Pieces, Pandora & More.</Typography>
                  <Box>
                    <Button className='btn' sx={{borderRadius:"50px",fontSize:"13px",padding:"9px 25px",marginTop:"38px", backgroundColor:"#C29958",border:"none",color:"#fff", textAlign:"center",transition:".4s",
                      "&:hover": {
                        "&.btn": {
                          backgroundColor:"#222222"
                        }
                      }
                    }}>Read More</Button>
                  </Box>
                </Box>
              </Box>
              <Box sx={{ position: 'relative',border:"none" }}>
                <img src={slide2} alt="logo2" style={{ width: '100%', height: '100%' }} />
                <Box sx={{ position: "absolute", top: "30%", left: "10%" }}>
                  <Typography variant='h2'>Family Jewelry </Typography>
                  <Typography variant='h2'>Collection</Typography>
                  <Typography fontSize={"18px"} color={"#222222"} marginTop={"10px"}>Designer Jewelry Necklaces-Bracelets-Earings</Typography>
                  <Box>
                    <Button className='btn' sx={{borderRadius:"50px",fontSize:"13px",padding:"9px 25px",marginTop:"38px", backgroundColor:"#C29958",border:"none",color:"#fff", textAlign:"center",transition:".4s",
                      "&:hover": {
                        "&.btn": {
                          backgroundColor:"#222222"
                        }
                      }
                    }}>Read More</Button>
                  </Box>
                </Box>
              </Box>
              <Box sx={{ position: 'relative',border:"none" }}>
                <img src={slide3} alt="logo3" style={{ width: '100%', height: '100%' }} />
                <Box sx={{ position: "absolute", top: "20%", left: "60%" }}>
                  <Typography variant='h2'>Diamonds Jewelry</Typography>
                  <Typography variant='h2'>Collection</Typography>
                  <Typography fontSize={"17px"} color={"#222222"} marginTop={"10px"}>Shukra Yogam & Silver Power Silver Saving Schemes.</Typography>
                  <Box>
                    <Button className='btn' sx={{borderRadius:"50px",fontSize:"13px",padding:"9px 25px",marginTop:"38px", backgroundColor:"#C29958",border:"none",color:"#fff", textAlign:"center",transition:".4s",
                      "&:hover": {
                        "&.btn": {
                          backgroundColor:"#222222"
                        }
                      }
                    }}>Read More</Button>
                  </Box>
                </Box>
              </Box>
            </Slider>
          </Box>
        </Grid>
    </Box>
  );
}

export default ServicesLogo;