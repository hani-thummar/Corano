import React from 'react'
import { Box, Container, Grid, Typography } from '@mui/material';
import p1 from '../../assets/img/HomePage/P-1.webp'
import p2 from '../../assets/img/HomePage/P-2.webp'
import p3 from '../../assets/img/HomePage/P-3.webp'
import p4 from '../../assets/img/HomePage/P-4.webp'

function Products() {
    return (
        <Box>
            <Container>
                <Grid container rowSpacing={1} columnSpacing={{ xs: 1, sm: 2, md: 3 }}>
                    <Grid item xs={6} sx={{ position: "relative" }}>
                        <img src={p1} alt="" />
                        <Box sx={{ position: "absolute", top: "20%", left: "68%" }}>
                            <Typography sx={{ color: "#777777" }} fontWeight={"600"} >BEAUTIFUL</Typography>
                            <Typography fontWeight={"700"} fontSize={"30px"} marginTop={"10px"}>Wedding</Typography>
                            <Typography fontWeight={"700"} fontSize={"30px"}>Rings</Typography>
                            <Typography className='shopNow' marginTop={"30px"} borderBottom={"2px solid black"} width={"76px"}
                                sx={{
                                    transition: ".3s", "&:hover": {
                                        "&.shopNow": {
                                            color: "#C29958 !important",
                                            borderBottom: "2px solid #C29958"
                                        }
                                    }
                                }}
                            >Shop Now</Typography>
                        </Box>
                    </Grid>
                    <Grid item xs={6} sx={{ position: "relative" }}>
                        <img src={p2} alt="" />
                        <Box sx={{ position: "absolute", top: "20%", left: "50%" }}>
                            <Typography sx={{ color: "#777777", textAlign:"center" }} fontWeight={"600"} >EARRINGS</Typography>
                            <Typography fontWeight={"700"} fontSize={"30px"} sx={{ whiteSpace: "nowrap", }}>Tangerine Floral </Typography>
                            <Typography fontWeight={"700"} fontSize={"30px"} sx={{ textAlign: "center" }}>Earring</Typography>
                            <Typography className='shopNow' marginLeft={"80px"} marginTop={"30px"} borderBottom={"2px solid black"} width={"76px"}
                                sx={{ transition: ".3s", "&:hover": {
                                        "&.shopNow": {
                                            color: "#C29958 !important",
                                            borderBottom: "2px solid #C29958"
                                        }
                                    }
                                }}
                            >Shop Now</Typography>
                        </Box>
                    </Grid>
                    <Grid item xs={6} sx={{ position: "relative" }}>
                        <img src={p3} alt="" />
                        <Box sx={{ position: "absolute", top: "20%", left: "64%" }}>
                            <Typography sx={{ color: "#777777", textAlign:"center" }} fontWeight={"600"} >NEW ARRIVALLS</Typography>
                            <Typography fontWeight={"700"} fontSize={"30px"} sx={{ whiteSpace: "nowrap", textAlign:"center"}}>Pearl</Typography>
                            <Typography fontWeight={"700"} fontSize={"30px"} sx={{ textAlign: "center" }}>Necklaces</Typography>
                            <Typography className='shopNow' marginLeft={"40px"} marginTop={"30px"} borderBottom={"2px solid black"} width={"76px"}
                                sx={{ transition: ".3s", "&:hover": {
                                        "&.shopNow": {
                                            color: "#C29958 !important",
                                            borderBottom: "2px solid #C29958"
                                        }
                                    }
                                }}
                            >Shop Now</Typography>
                        </Box>
                    </Grid>
                    <Grid item xs={6} sx={{ position: "relative" }}>
                        <img src={p4} alt="" />
                        <Box sx={{ position: "absolute", top: "20%", left: "68%" }}>
                            <Typography sx={{ color: "#777777" }} fontWeight={"600"} >BEAUTIFUL</Typography>
                            <Typography fontWeight={"700"} fontSize={"30px"} marginTop={"10px"}>Wedding</Typography>
                            <Typography fontWeight={"700"} fontSize={"30px"}>Rings</Typography>
                            <Typography className='shopNow' marginTop={"30px"} borderBottom={"2px solid black"} width={"76px"}
                                sx={{
                                    transition: ".3s", "&:hover": {
                                        "&.shopNow": {
                                            color: "#C29958 !important",
                                            borderBottom: "2px solid #C29958"
                                        }
                                    }
                                }}
                            >Shop Now</Typography>
                        </Box>
                    </Grid>
                </Grid>
            </Container>
        </Box>
    )
}

export default Products
